DELIMITER $$
CREATE FUNCTION total_course_sold(c_id INT) RETURNS DECIMAL(8,2)
BEGIN
    DECLARE s_price DECIMAL(8,2) DEFAULT 0.0;
    DECLARE c_price DECIMAL(8,2);
    --
    IF ((SELECT COUNT(*) FROM `course` WHERE course.id = c_id) = 0)
    THEN
    	SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'course not found';
		RETURN 0.0;
    END IF;
    --
    SET c_price = (SELECT course.course_price FROM `course` WHERE course.id = c_id);
    IF ((SELECT COUNT(*) FROM `course` WHERE course.specialization_id IS NOT NULL) > 0)
    THEN
        SET s_price = c_price;
    END IF;
    RETURN s_price + c_price;
END $$
DELIMITER ;
