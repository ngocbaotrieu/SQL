DELIMITER $$
CREATE PROCEDURE student_list_course
(
    IN std_id INT
)
BEGIN
	SELECT C.course_image AS 'image', C.name AS 'course name', I.name AS 'institution name'
	FROM `course` AS C, `course_created_by` AS B, `institution` AS I, `student` AS S, `enrolled_course` AS E, `course_session` AS Cs
	WHERE E.student_id = std_id
    	AND E.course_session_id = Cs.id
        AND Cs.course_id = C.id
        AND B.course_id = C.id
        AND B.institution_id = I.id
	ORDER BY C.name;
END $$
DELIMITER ;
