DELIMITER $$
CREATE PROCEDURE student_course_summary
(
    IN std_id INT,
    IN inst_id INT
)
BEGIN
	SELECT I.name AS 'institution name', COUNT(*) AS 'bought course', SUM(C.course_price) AS 'total' 
	FROM `course` AS C, `course_created_by` AS B, `institution` AS I, `student` AS S, `enrolled_course` AS E, `course_session` AS Cs
	WHERE E.student_id = std_id
    	AND E.course_session_id = Cs.id
        AND Cs.course_id = C.id
        AND B.course_id = C.id
        AND B.institution_id = I.id
    GROUP BY I.id
    HAVING (I.id = inst_id)
	ORDER BY I.id;
END $$
DELIMITER ;