DELIMITER $$
CREATE PROCEDURE create_course
(
	c_id int,
	c_name varchar(255),
	c_commitment varchar(255),
	c_description text,
	c_specialization_id int,
	c_min_grade decimal(5,2),
	c_price decimal(8,2),
	c_active bit
)
sp: BEGIN
	--
	IF (c_id IS NULL OR LENGTH(c_id) = 0)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'invalid course name';
		LEAVE sp;
	END IF;
	--
	IF (c_name IS NULL OR LENGTH(c_name) = 0)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'invalid course name';
		LEAVE sp;
	END IF;
	--
	IF (c_commitment IS NULL OR LENGTH(c_commitment) = 0)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'invalid course commitment';
		LEAVE sp;
	END IF;
	--
	IF (c_description IS NULL OR LENGTH(c_description) = 0)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'invalid course description';
		LEAVE sp;
	END IF;
	--
	IF (c_min_grade IS NULL OR LENGTH(c_min_grade) = 0)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'invalid course min grade';
		LEAVE sp;
	END IF;
	--
	IF (c_price IS NULL OR LENGTH(c_price) = 0)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'invalid course price';
		LEAVE sp;
	END IF;
	--
	IF (c_active IS NULL OR LENGTH(c_active) = 0)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'invalid course activation';
		LEAVE sp;
	END IF;
	-- insert into course table
	INSERT INTO course (id, name, commitment, description, specialization_id, min_grade, course_price, active)
	VALUES(c_id, c_name, c_commitment, c_description, c_specialization_id, c_min_grade, c_price, c_active);
END $$
DELIMITER ;
